package com.noxxa.hsswitchern.manager

import android.content.Context
import android.net.Uri
import androidx.documentfile.provider.DocumentFile

object LoginSwitcher {

    fun switchAccount(
        context: Context,
        accountsFolderUri: Uri,
        hadesFolderUri: Uri,
        accountName: String
    ): Boolean {

        val accountsFolder =
            DocumentFile.fromTreeUri(
                context,
                accountsFolderUri
            ) ?: return false

        val hadesFolder =
            DocumentFile.fromTreeUri(
                context,
                hadesFolderUri
            ) ?: return false

        val accountFolder =
            accountsFolder.findFile(accountName)
                ?: return false

        val source =
            accountFolder.findFile("login.info")
                ?: return false

        val target =
            hadesFolder.findFile("login.info")

        target?.delete()

        val newFile =
            hadesFolder.createFile(
                "application/octet-stream",
                "login.info"
            ) ?: return false

        context.contentResolver.openInputStream(source.uri).use { input ->

            context.contentResolver.openOutputStream(newFile.uri).use { output ->

                if (input != null && output != null) {
                    input.copyTo(output)
                }

            }

        }

        return true

    }

}