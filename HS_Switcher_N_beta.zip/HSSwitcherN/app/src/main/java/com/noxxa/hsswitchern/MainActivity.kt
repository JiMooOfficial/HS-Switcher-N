package com.noxxa.hsswitchern

import androidx.compose.runtime.*
import android.content.Context
import android.net.Uri
import android.content.Intent
import androidx.activity.result.contract.ActivityResultContracts
import com.noxxa.hsswitchern.picker.FolderPicker
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import com.noxxa.hsswitchern.manager.AccountManager
import com.noxxa.hsswitchern.ui.HomeScreen
import com.noxxa.hsswitchern.ui.theme.HSSwitcherNTheme
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue

class MainActivity : ComponentActivity() {

    private var accounts by mutableStateOf(
        emptyList<String>()
    )

    private var hadesFolder by mutableStateOf<String?>(null)

    private val prefs by lazy {
        getSharedPreferences(
            "settings",
            Context.MODE_PRIVATE
        )
    }

    private val folderPicker =
        registerForActivityResult(
            ActivityResultContracts.StartActivityForResult()
        ) { result ->

            if (result.resultCode == RESULT_OK) {

                val uri = result.data?.data

                if (uri != null) {

                    FolderPicker.saveFolderPermission(
                        this,
                        uri
                    )

                    accounts = AccountManager.getAccounts(
                        this,
                        uri
                    )

                    prefs.edit()
                        .putString(
                            "accounts_folder",
                            uri.toString()
                        )
                        .apply()

                    var accounts =
                        AccountManager.getAccounts(
                            this,
                            uri
                        )

                    accounts = AccountManager.getAccounts(
                        this,
                        uri
                    )
                }
            }
        }

    private val hadesFolderPicker =
        registerForActivityResult(
            ActivityResultContracts.StartActivityForResult()
        ) { result ->

            if (result.resultCode == RESULT_OK) {

                val uri = result.data?.data

                if (uri != null) {

                    FolderPicker.saveFolderPermission(
                        this,
                        uri
                    )

                    hadesFolder = uri.toString()

                }
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            HSSwitcherNTheme {
                HomeScreen(
                    accounts = accounts,

                    onSelectAccountsFolder = {

                        FolderPicker.openFolderPicker(
                            folderPicker
                        )

                    },

                    onSelectHadesFolder = {

                        FolderPicker.openFolderPicker(
                            hadesFolderPicker
                        )

                    }
                )
            }
        }
    }
}