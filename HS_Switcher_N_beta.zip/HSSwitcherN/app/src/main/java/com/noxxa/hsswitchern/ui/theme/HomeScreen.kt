package com.noxxa.hsswitchern.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp


@Composable
fun HomeScreen(
    accounts: List<String>,
    onSelectAccountsFolder: () -> Unit,
    onSelectHadesFolder: () -> Unit
) {

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {

        Spacer(
            modifier = Modifier.height(40.dp)
        )

        Text(
            text = "HS Switcher N by Mashiro_Yui",
            style = MaterialTheme.typography.headlineMedium
        )

        Spacer(
            modifier = Modifier.height(20.dp)
        )


        if (accounts.isEmpty()) {

            Text(
                text = "Select an account folder"
            )

        } else {

            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
            ) {

                items(accounts) { account ->

                    Button(
                        onClick = {

                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                    ) {

                        Text(account)

                    }
                }
            }
        }


        Spacer(
            modifier = Modifier.height(20.dp)
        )


        Button(
            onClick = {
                onSelectAccountsFolder()
            }
        ) {

            Text("Select Accounts Folder")

        }

        Spacer(
            modifier = Modifier.height(10.dp)
        )


        Button(
            onClick = {
                onSelectHadesFolder()
            }
        ) {

            Text("Select Hades Star Folder")

        }
    }
}