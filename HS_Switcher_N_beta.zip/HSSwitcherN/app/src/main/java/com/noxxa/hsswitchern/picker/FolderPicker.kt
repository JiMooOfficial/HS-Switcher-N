package com.noxxa.hsswitchern.picker

import android.content.Context
import android.content.Intent
import androidx.activity.result.ActivityResultLauncher

object FolderPicker {

    fun openFolderPicker(
        launcher: ActivityResultLauncher<Intent>
    ) {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT_TREE)

        intent.addFlags(
            Intent.FLAG_GRANT_READ_URI_PERMISSION or
                    Intent.FLAG_GRANT_WRITE_URI_PERMISSION or
                    Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION
        )

        launcher.launch(intent)
    }


    fun saveFolderPermission(
        context: Context,
        uri: android.net.Uri
    ) {
        val takeFlags = Intent.FLAG_GRANT_READ_URI_PERMISSION or
                Intent.FLAG_GRANT_WRITE_URI_PERMISSION

        context.contentResolver.takePersistableUriPermission(
            uri,
            takeFlags
        )
    }
}