package com.noxxa.hsswitchern.manager

import android.content.Context
import android.net.Uri
import androidx.documentfile.provider.DocumentFile

object AccountManager {

    fun getAccounts(
        context: Context,
        folderUri: Uri
    ): List<String> {

        val folder = DocumentFile.fromTreeUri(
            context,
            folderUri
        )

        if (folder == null) {
            return emptyList()
        }

        return folder.listFiles()
            .filter { it.isDirectory }
            .map { it.name ?: "Unknown" }
    }
}